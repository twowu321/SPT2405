import pygame

# 将屏幕大小和背景图片路径作为常量处理，提高代码的可维护性
SCREEN_WIDTH, SCREEN_HEIGHT = 480, 700
SCREEN_RECT = pygame.Rect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)
BACKGROUND_IMAGE_PATH = "images/background.png"

class GameSprite(pygame.sprite.Sprite):
    """
    飞机大战游戏精灵
    """
    def __init__(self, image_name, speed=1):
        # 游戏精灵初始化
        super().__init__()
        try:
            self.image = pygame.image.load(image_name)
        except pygame.error as e:
            raise FileNotFoundError(f"无法加载图像: {image_name}. {e}") from e
        self.rect = self.image.get_rect()
        self.speed = speed

    def update(self):
        # 更新精灵位置的通用逻辑
        self.rect.y += self.speed

class BackGround(GameSprite):
    """
    游戏背景精灵
    """
    def __init__(self, is_alt=False):
        # 游戏背景初始化
        super().__init__(BACKGROUND_IMAGE_PATH)
        if is_alt:
            self.rect.y = -self.rect.height

    def update(self):
        # 背景循环向下位移的逻辑
        super().update()
        if self.rect.y >= SCREEN_RECT.height:
            self.rect.y = -self.rect.height

# 示例：创建背景对象
# 这部分代码是使用示例，不会包含在类定义中
# background = BackGround()
# background.update()
