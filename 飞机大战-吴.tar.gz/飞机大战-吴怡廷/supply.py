import pygame
import random
# 子弹补给类，继承自pygame的Sprite类
class Bullet_Supply(pygame.sprite.Sprite):
    def __init__(self, bg_size):
        # 初始化Sprite类
        pygame.sprite.Sprite.__init__(self)

        # 加载子弹补给的图像并处理透明度
        self.image = pygame.image.load("images/bullet_supply.png").convert_alpha()
        # 获取图像的矩形区域
        self.rect = self.image.get_rect()
        # 获取背景的宽度和高度
        self.width, self.height = bg_size[0], bg_size[1]
        # 随机设置子弹补给的初始位置在屏幕顶部之外
        self.rect.left, self.rect.bottom = random.randint(0, self.width - self.rect.width), -100
        # 设置子弹补给下落的速度
        self.speed = 5
        # 设置子弹补给是否活跃的标志
        self.active = False
        # 创建子弹补给的遮罩，用于碰撞检测
        self.mask = pygame.mask.from_surface(self.image)

    # 控制子弹补给下落的函数
    def move(self):
        # 如果子弹补给未到达屏幕顶部，则继续下落
        if self.rect.top < self.height:
            self.rect.top += self.speed
        else:
            # 如果到达屏幕顶部，则设置为非活跃状态
            self.active = False

    # 重置子弹补给状态的函数
    def reset(self):
        # 设置为活跃状态
        self.active = True
        # 随机设置子弹补给的初始位置在屏幕顶部之外
        self.rect.left, self.rect.bottom = random.randint(0, self.width - self.rect.width), -100

# 炸弹补给类，继承自pygame的Sprite类
class Bomb_Supply(pygame.sprite.Sprite):
    def __init__(self, bg_size):
        # 初始化Sprite类
        pygame.sprite.Sprite.__init__(self)

        # 加载炸弹补给的图像并处理透明度
        self.image = pygame.image.load("images/bomb_supply.png").convert_alpha()
        # 获取图像的矩形区域
        self.rect = self.image.get_rect()
        # 获取背景的宽度和高度
        self.width, self.height = bg_size[0], bg_size[1]
        # 随机设置炸弹补给的初始位置在屏幕顶部之外
        self.rect.left =random.randint(0, self.width - self.rect.width)
        self.rect.bottom = -100
        # 设置炸弹补给下落的速度
        self.speed = 5
        # 设置炸弹补给是否活跃的标志
        self.active = False
        # 创建炸弹补给的遮罩，用于碰撞检测
        self.mask = pygame.mask.from_surface(self.image)

    # 控制炸弹补给下落的函数
    def move(self):
        # 如果炸弹补给未到达屏幕顶部，则继续下落
        if self.rect.top < self.height:
            self.rect.top += self.speed
        else:
            # 如果到达屏幕顶部，则设置为非活跃状态
            self.active = False

    # 重置炸弹补给状态的函数
    def reset(self):
        # 设置为活跃状态
        self.active = True
        # 随机设置炸弹补给的初始位置在屏幕顶部之外
        self.rect.left, self.rect.bottom = random.randint(0, self.width - self.rect.width), -100