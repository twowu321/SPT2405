import pygame

# 定义飞机类，继承自pygame的Sprite类
class plane(pygame.sprite.Sprite):
    def __init__(self, bg_size):
        # 初始化Sprite类
        pygame.sprite.Sprite.__init__(self)

        # 加载飞机正常状态的两种图像
        self.image1 = pygame.image.load("images/me1.png").convert_alpha()
        self.image2 = pygame.image.load("images/me2.png").convert_alpha()
        # 加载飞机爆炸时的动画图像，并存入列表
        self.destroy_image = []
        self.destroy_image.extend([
            pygame.image.load("images/me_destroy_1.png").convert_alpha(),
            pygame.image.load("images/me_destroy_2.png").convert_alpha(),
            pygame.image.load("images/me_destroy_3.png").convert_alpha(),
            pygame.image.load("images/me_destroy_4.png").convert_alpha(),
        ])
        # 设置飞机初始状态为活跃
        self.active = True
        # 使用image1获取飞机的矩形区域
        self.rect = self.image1.get_rect()
        # 获取背景大小，用于后续飞机位置的计算
        self.width, self.height = bg_size[0], bg_size[1]
        # 计算并设置飞机的初始位置
        self.rect.left, self.rect.top = \
                        (self.width - self.rect.width) // 2, \
                        self.height - self.rect.height - 60
        # 设置飞机移动速度
        self.speed = 10
        # 创建飞机的碰撞掩码，用于碰撞检测
        self.mask = pygame.mask.from_surface(self.image1)
        # 设置飞机初始为可被击中状态
        self.invincible = False

    # 飞机向上移动的方法
    def moveUp(self):
        # 如果飞机顶部没有超出屏幕，则向上移动
        if self.rect.top > 0:
            self.rect.top -= self.speed
        else:
            self.rect.top = 0

    # 飞机向下移动的方法
    def moveDown(self):
        # 如果飞机底部没有超出屏幕，则向下移动
        if self.rect.bottom < self.height - 60:
            self.rect.top += self.speed
        else:
            self.rect.bottom = self.height - 60

    # 飞机向左移动的方法
    def moveLeft(self):
        # 如果飞机左侧没有超出屏幕，则向左移动
        if self.rect.left > 0:
            self.rect.left -= self.speed
        else:
            self.rect.left = 0

    # 飞机向右移动的方法
    def moveRight(self):
        # 如果飞机右侧没有超出屏幕，则向右移动
        if self.rect.right < self.width:
            self.rect.left += self.speed
        else:
            self.rect.right = self.width

    # 飞机重置位置和状态的方法
    def reset(self):
        # 重新设置飞机的位置到屏幕中央
        self.rect.left, self.rect.top = \
                        (self.width - self.rect.width) // 2, \
                        self.height - self.rect.height - 60
        # 激活飞机，使其可以再次移动和射击
        self.active = True
        # 设置飞机为无敌状态，用于短暂的无敌时间效果
        self.invincible = True
