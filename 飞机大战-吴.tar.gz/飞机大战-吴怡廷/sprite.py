# 整合所有的精灵类
import pygame
from bullet import *
from enemy import *
from plane import *
from supply import *
Bullet1 = Bullet1("images/bullet1.png")