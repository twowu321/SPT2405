import pygame
# 定义子弹类Bullet1，继承自pygame.sprite.Sprite
# 该类用于创建和管理游戏中的子弹对象
class Bullet1(pygame.sprite.Sprite):
    def __init__(self, positon):
        # 初始化子弹对象
        pygame.sprite.Sprite.__init__(self)
        # 加载子弹图像并优化其透明度处理
        self.image = pygame.image.load("images/bullet1.png").convert_alpha()
        # 获取图像的矩形区域信息
        self.rect = self.image.get_rect()
        # 设置子弹的初始位置
        self.rect.left, self.rect.top = positon
        # 设置子弹的移动速度
        self.speed = 12
        # 设置子弹是否活跃的标志
        self.active = True
        # 创建子弹的碰撞掩码
        self.mask = pygame.mask.from_surface(self.image)

    # 子弹移动的方法
    def move(self):
        # 子弹向上移动
        self.rect.top -= self.speed
        # 如果子弹移出屏幕，则设置为非活跃状态
        if self.rect.top < 0:
            self.active = False

    # 子弹重置的方法
    def reset(self, position):
        # 重置子弹的位置
        self.rect.left, self.rect.top = position
        # 将子弹设置为活跃状态
        self.active = True


# 定义子弹类Bullet2，同样继承自pygame.sprite.Sprite
# 该类用于创建和管理另一种类型的子弹对象
class Bullet2(pygame.sprite.Sprite):
    def __init__(self, positon):
        # 初始化子弹对象
        pygame.sprite.Sprite.__init__(self)

        # 加载子弹图像并优化其透明度处理
        self.image = pygame.image.load("images/bullet2.png").convert_alpha()
        # 获取图像的矩形区域信息
        self.rect = self.image.get_rect()
        # 设置子弹的初始位置
        self.rect.left, self.rect.top = positon
        # 设置子弹的移动速度
        self.speed = 15
        # 设置子弹是否活跃的标志
        self.active = True
        # 创建子弹的碰撞掩码
        self.mask = pygame.mask.from_surface(self.image)

    # 子弹移动的方法
    def move(self):
        # 子弹向上移动
        self.rect.top -= self.speed
        # 如果子弹移出屏幕，则设置为非活跃状态
        if self.rect.top < 0:
            self.active = False

    # 子弹重置的方法
    def reset(self, position):
        # 重置子弹的位置
        self.rect.left, self.rect.top = position
        # 将子弹设置为活跃状态
        self.active = True
